// background/config.js — NEVER COMMIT (gitignored)
export const GOOGLE_AI_API_KEY = 'AIzaSyDRgEr6v06tcK33NHc5No2akUb1MU0770k';
export const SUPABASE_URL = 'https://kjbeubcbhbjrnbnztwap.supabase.co';
export const SUPABASE_ANON_KEY = 'sb_publishable_H6QbLUuEBB49f-Hyf0Tybw_GT7bxwqr';
export const ELEVENLABS_API_KEY = '3b26d9b26e20256d87d94e7e611b317fb3c8e4f63e8c3723d4efbe3c38476d7a';
export const ELEVENLABS_VOICE_ID = '8tZdziIM3Y7ERvK9TUjy';
export const GROQ_API_KEY = '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';
