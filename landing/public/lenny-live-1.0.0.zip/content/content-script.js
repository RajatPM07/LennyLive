// content/content-script.js
// Detection + Shadow DOM UI injection for Lenny Live.
// MV3 content scripts cannot use ES modules — this is one intentionally long file.

// ─── Shadow DOM Setup ────────────────────────────────────────────────────────

const host = document.createElement('div');
host.id = 'lenny-live-root';
const shadow = host.attachShadow({ mode: 'open' }); // open = inspectable in DevTools
document.body.appendChild(host);

// Fonts: use system font stack — injecting Google Fonts into document.head violates
// font-src CSP on Notion, Linear, Jira, and most enterprise apps.

// Inject all styles into shadow root
const style = document.createElement('style');
style.textContent = `
  /* ── LennyLive Unified Theme ── */
  :host {
    --bg-surface: #fdfcf6;
    --bg-surface-hover: #f3f0e6;
    --bg-dark: #1a1c1c;
    --text-dark: #1a1c1c;
    --text-light: #ffffff;
    --text-muted: #5e5e5e;
    --accent-orange: #ff6e40;
    --accent-orange-dark: #a23f1d;
    --pill-bg: #fef3c7;
    --pill-text: #92400e;
    --border-light: rgba(0,0,0,0.05);
    --error-bg: #1a1a1a;
    --font-sans: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
    --font-serif: Georgia, 'Times New Roman', serif;
  }
  * { box-sizing: border-box; }

  /* 1. Listening Indicator */
  #ll-indicator {
    display: none;
    position: fixed;
    bottom: 32px;
    right: 32px;
    background: var(--bg-surface);
    border: 1px solid var(--border-light);
    border-radius: 24px;
    padding: 8px 16px;
    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
    z-index: 2147483647;
    pointer-events: none;
    align-items: center;
    gap: 12px;
  }
  #ll-indicator:not(.hidden) { display: flex; }
  #ll-indicator.hidden { display: none !important; }
  .ll-wave { display: flex; align-items: flex-end; gap: 2px; height: 12px; }
  .ll-bar { width: 2px; background: var(--accent-orange); border-radius: 1px; animation: ll-bounce 1s ease-in-out infinite; }
  .ll-bar:nth-child(1) { height: 8px; }
  .ll-bar:nth-child(2) { height: 12px; animation-delay: 0.2s; }
  .ll-bar:nth-child(3) { height: 6px; animation-delay: 0.4s; }
  .ll-bar:nth-child(4) { height: 10px; animation-delay: 0.6s; }
  @keyframes ll-bounce { 0%, 100% { transform: scaleY(0.5); } 50% { transform: scaleY(1); } }
  #ll-text { font-family: var(--font-sans); font-size: 13px; font-weight: 500; color: var(--text-dark); }
  #ll-indicator.loading .ll-wave { display: none; }
  #ll-indicator.loading #ll-text { animation: ll-pulse 1.5s infinite; }
  @keyframes ll-pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }

  /* 2. Toast */
  #ll-toast {
    display: none;
    position: fixed;
    bottom: 32px;
    right: 32px;
    background: var(--error-bg);
    border-radius: 8px;
    padding: 12px 16px;
    font-family: var(--font-sans);
    font-size: 12px;
    color: var(--text-light);
    z-index: 2147483647;
    pointer-events: none;
    max-width: 280px;
    line-height: 1.4;
    box-shadow: 0 10px 15px -3px rgba(0,0,0,0.3);
    opacity: 0;
    transform: translateY(8px);
    transition: opacity 0.15s ease-out, transform 0.15s ease-out;
  }
  #ll-toast.visible { display: block; opacity: 1; transform: translateY(0); }
  #ll-toast.fading { opacity: 0; transform: translateY(8px); }
  .toast-content { display: flex; align-items: center; gap: 12px; }
  .toast-icon { color: #f87171; font-weight: bold; }

  /* 3. Tooltip */
  #ll-tooltip {
    display: none;
    position: fixed;
    bottom: 80px;
    right: 32px;
    background: var(--error-bg);
    border-radius: 4px;
    padding: 8px 12px;
    font-family: var(--font-sans);
    font-size: 11px;
    color: var(--text-light);
    z-index: 2147483647;
    pointer-events: none;
  }
  #ll-tooltip::after {
    content: ''; position: absolute; top: 100%; left: 50%; transform: translateX(-50%);
    border: 4px solid transparent; border-top-color: var(--error-bg);
  }
  #ll-tooltip.visible { display: block; }

  /* 4. Pulse Dot (shared by selection dot and badge pill) */
  .pulse-dot-wrapper {
    position: relative; width: 14px; height: 14px; background: var(--accent-orange);
    border-radius: 50%; z-index: 10; box-shadow: 0 0 12px rgba(255,110,64,0.4); transition: transform 0.3s;
  }
  .pulse-dot-wrapper::before {
    content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0;
    background: var(--accent-orange); border-radius: 50%;
    animation: ll-pulse-ring 2s cubic-bezier(0.455, 0.03, 0.515, 0.955) infinite;
  }
  @keyframes ll-pulse-ring { 0% { transform: scale(0.8); opacity: 1; } 100% { transform: scale(2.5); opacity: 0; } }

  /* 5. Postcard */
  #ll-postcard {
    position: fixed;
    bottom: 32px; right: 32px; width: 320px;
    background: var(--bg-surface); border: 1px solid var(--border-light); border-radius: 12px;
    box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04);
    font-family: var(--font-sans); z-index: 2147483647; overflow: hidden;
    display: flex; flex-direction: column;
  }
  #ll-postcard.hidden { display: none; }
  #ll-postcard:not(.hidden):not(.ll-postcard-hiding) { animation: ll-postcard-in 0.3s cubic-bezier(0.16, 1, 0.3, 1); }
  #ll-postcard.ll-postcard-hiding { animation: ll-postcard-out 0.2s ease-in forwards; }
  @keyframes ll-postcard-in { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
  @keyframes ll-postcard-out { from { transform: translateY(0); opacity: 1; } to { transform: translateY(20px); opacity: 0; } }

  .pc-header { display: flex; justify-content: space-between; align-items: center; padding: 16px 16px 8px; }
  .pc-logo { font-family: var(--font-serif); font-size: 16px; font-weight: 600; font-style: italic; color: var(--text-dark); }
  .pc-actions { display: flex; gap: 12px; }
  .pc-btn { background: none; border: none; cursor: pointer; color: var(--text-muted); font-size: 14px; display: flex; align-items: center; transition: color 0.2s; padding: 0; }
  .pc-btn:hover { color: var(--accent-orange); }

  .pc-body { padding: 8px 24px 16px; display: flex; flex-direction: column; }
  .pc-framing { font-family: var(--font-serif); font-style: italic; font-size: 13px; color: var(--text-muted); margin: 0 0 12px 0; display: none; }
  .pc-topic { align-self: flex-start; background: var(--pill-bg); color: var(--pill-text); font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; padding: 4px 10px; border-radius: 12px; margin-bottom: 16px; }
  .pc-quote-wrapper { position: relative; max-height: 100px; overflow: hidden; transition: max-height 0.4s ease-in-out; }
  .pc-quote { font-family: var(--font-serif); font-size: 18px; line-height: 1.4; color: var(--text-dark); font-style: italic; margin: 0; }
  .pc-fade { position: absolute; bottom: 0; left: 0; right: 0; height: 48px; background: linear-gradient(transparent, var(--bg-surface)); transition: opacity 0.4s; }
  .pc-quote-wrapper.expanded { max-height: 1000px; }
  .pc-quote-wrapper.expanded .pc-fade { opacity: 0; pointer-events: none; }
  .pc-read-more { align-self: flex-start; margin-top: 12px; background: var(--bg-dark); color: var(--bg-surface); border: none; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; padding: 8px 16px; border-radius: 16px; cursor: pointer; transition: background 0.2s; }
  .pc-read-more:hover { background: var(--accent-orange-dark); }
  .pc-read-more.hidden { display: none; }

  .pc-footer { border-top: 1px solid var(--border-light); padding: 12px 24px 14px; background: rgba(0,0,0,0.02); display: flex; justify-content: space-between; align-items: center; }
  .pc-footer-meta { display: flex; flex-direction: column; gap: 2px; }
  .pc-guest { font-family: var(--font-sans); font-weight: 700; font-size: 12px; color: var(--text-dark); }
  .pc-episode { font-family: var(--font-sans); font-size: 10px; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.05em; }
  .pc-source-link { font-family: var(--font-sans); font-size: 10px; font-weight: 600; color: var(--accent-orange); text-decoration: none; white-space: nowrap; opacity: 0.85; transition: opacity 0.15s; }
  .pc-source-link:hover { opacity: 1; }
  .pc-source-link.hidden { display: none; }

  /* 6. Related Insights (shown on Read more expand) */
  .pc-related { margin-top: 16px; border-top: 1px solid var(--border-light); padding-top: 12px; display: flex; flex-direction: column; gap: 10px; }
  .pc-related.hidden { display: none; }
  .pc-related-header { font-family: var(--font-sans); font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--text-muted); margin-bottom: 2px; }
  .pc-related-item { background: rgba(0,0,0,0.02); border-radius: 8px; padding: 10px 12px; display: flex; flex-direction: column; gap: 4px; }
  .pc-related-topic { font-family: var(--font-sans); font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--pill-text); background: var(--pill-bg); padding: 2px 7px; border-radius: 8px; align-self: flex-start; }
  .pc-related-quote { font-family: var(--font-serif); font-style: italic; font-size: 12px; line-height: 1.45; color: var(--text-dark); }
  .pc-related-meta { display: flex; justify-content: space-between; align-items: center; margin-top: 2px; }
  .pc-related-guest { font-family: var(--font-sans); font-size: 10px; font-weight: 600; color: var(--text-muted); }
  .pc-related-link { font-family: var(--font-sans); font-size: 10px; font-weight: 600; color: var(--accent-orange); text-decoration: none; opacity: 0.85; transition: opacity 0.15s; }
  .pc-related-link:hover { opacity: 1; }

  /* 7. Selection Dot */
  #ll-selection-dot {
    display: none; position: fixed; z-index: 2147483647; cursor: pointer;
  }
  #ll-selection-dot.visible { display: block; }

  /* 8. Badge Pill (replaces Write+Pause Dot + Questions Panel) */
  #ll-badge-pill {
    display: none; position: fixed; bottom: 32px; right: 32px;
    z-index: 2147483647; flex-direction: column; align-items: flex-end; gap: 8px;
  }
  #ll-badge-pill.visible { display: flex; }

  .ll-badge-trigger {
    display: flex; align-items: center; gap: 10px;
    background: var(--bg-dark); border-radius: 20px;
    padding: 8px 16px 8px 12px;
    cursor: pointer; box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    transition: transform 0.15s, box-shadow 0.15s;
    border: none; font-family: var(--font-sans);
  }
  .ll-badge-trigger:hover { transform: translateY(-1px); box-shadow: 0 6px 16px rgba(0,0,0,0.2); }
  .ll-badge-dot {
    width: 8px; height: 8px; background: var(--accent-orange);
    border-radius: 50%; flex-shrink: 0;
    animation: ll-pulse-ring 2s cubic-bezier(0.455, 0.03, 0.515, 0.955) infinite;
  }
  .ll-badge-dot.loading {
    animation: ll-spin 1s linear infinite;
    border: 2px solid rgba(255,110,64,0.3); border-top-color: var(--accent-orange);
    background: transparent; width: 10px; height: 10px;
  }
  .ll-badge-text {
    font-size: 12px; font-weight: 500; color: var(--text-light);
    white-space: nowrap;
  }
  .ll-badge-arrow { font-size: 12px; color: rgba(255,255,255,0.5); margin-left: 2px; }

  /* Chips panel — expands below badge pill */
  .ll-chips-panel {
    display: none; width: 320px;
    background: #ffffff; border: 1px solid rgba(222,192,184,0.2); border-radius: 12px;
    box-shadow: 0 32px 32px -4px rgba(26,28,28,0.06);
    flex-direction: column; overflow: hidden; font-family: var(--font-sans);
    animation: ll-postcard-in 0.25s cubic-bezier(0.16, 1, 0.3, 1);
  }
  .ll-chips-panel.visible { display: flex; }
  .ll-chips-header {
    display: flex; justify-content: space-between; align-items: center;
    padding: 14px 16px 10px; border-bottom: 1px solid rgba(0,0,0,0.05);
  }
  .ll-chips-title { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--text-muted); }
  .ll-chips-close { background: none; border: none; font-size: 16px; color: var(--text-muted); cursor: pointer; padding: 2px 4px; border-radius: 4px; }
  .ll-chips-close:hover { background: rgba(0,0,0,0.05); color: var(--text-dark); }
  .ll-chips-list { padding: 10px 12px 14px; display: flex; flex-direction: column; gap: 8px; }
  .ll-chip-btn {
    width: 100%; text-align: left; padding: 12px 14px;
    border-radius: 10px; border: 1px solid rgba(222,192,184,0.25);
    background: #f9f9f9; cursor: pointer;
    transition: all 0.15s; display: flex; justify-content: space-between; align-items: flex-start;
    font-family: var(--font-sans);
  }
  .ll-chip-btn:hover { background: #ffffff; border-color: rgba(162,63,29,0.35); box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
  .ll-chip-btn-text { font-size: 13px; font-weight: 500; color: var(--text-dark); line-height: 1.4; padding-right: 12px; margin: 0; }
  .ll-chip-btn-arrow { color: rgba(162,63,29,0.4); font-size: 14px; transition: color 0.15s; flex-shrink: 0; margin-top: 1px; }
  .ll-chip-btn:hover .ll-chip-btn-arrow { color: #a23f1d; }

  /* Loading state for chips panel */
  .ll-chips-loading { padding: 20px 16px; display: flex; align-items: center; gap: 10px; }
  .ll-chips-loading-text { font-size: 12px; color: var(--text-muted); font-style: italic; }
  @keyframes ll-spin { to { transform: rotate(360deg); } }

  /* 9. Onboarding Panel */
  #ll-onboarding {
    position: fixed;
    bottom: 32px; right: 32px; width: 320px;
    background: var(--bg-surface); border: 1px solid var(--border-light); border-radius: 12px;
    box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04);
    font-family: var(--font-sans); z-index: 2147483647; overflow: hidden;
    display: flex; flex-direction: column;
  }
  #ll-onboarding.hidden { display: none; }
  #ll-onboarding:not(.hidden) { animation: ll-postcard-in 0.3s cubic-bezier(0.16, 1, 0.3, 1); }

  .ob-header { display: flex; justify-content: space-between; align-items: center; padding: 16px 16px 8px; }
  .ob-logo { font-family: var(--font-serif); font-size: 16px; font-weight: 600; font-style: italic; color: var(--text-dark); }
  .ob-close { background: none; border: none; cursor: pointer; color: var(--text-muted); font-size: 14px; padding: 0; transition: color 0.2s; }
  .ob-close:hover { color: var(--accent-orange); }

  .ob-body { padding: 16px 24px; display: flex; flex-direction: column; align-items: center; gap: 12px; }

  .ob-slide { display: flex; flex-direction: column; align-items: center; gap: 12px; width: 100%; }
  .ob-slide.hidden { display: none; }

  /* Slide 1 visual: large animated orange pulse dot */
  .ob-pulse-large {
    width: 48px; height: 48px;
    background: var(--accent-orange); border-radius: 50%;
    position: relative; flex-shrink: 0;
  }
  .ob-pulse-large::before {
    content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0;
    background: var(--accent-orange); border-radius: 50%;
    animation: ll-pulse-ring 2s cubic-bezier(0.455, 0.03, 0.515, 0.955) infinite;
  }

  /* Slide 2 visual: keyboard mock */
  .ob-kbd-mock { display: flex; flex-direction: column; align-items: center; gap: 6px; }
  .ob-kbd { display: flex; align-items: center; gap: 6px; }
  .ob-key {
    background: #ffffff; border: 1px solid #d1d5db; border-bottom: 3px solid #9ca3af;
    border-radius: 6px; padding: 6px 14px; font-size: 13px; font-weight: 600;
    color: var(--text-dark); box-shadow: 0 1px 2px rgba(0,0,0,0.06);
  }
  .ob-key-sep { font-size: 14px; color: var(--text-muted); }
  .ob-kbd-label { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--accent-orange); text-align: center; }

  /* Text elements */
  .ob-headline {
    font-family: var(--font-serif); font-size: 18px; font-weight: 400;
    line-height: 1.3; color: var(--text-dark); text-align: center; margin: 0;
  }
  .ob-text {
    font-size: 13px; line-height: 1.55; color: var(--text-muted); text-align: center; margin: 0;
  }
  .ob-text strong { font-weight: 600; color: var(--text-dark); }
  .ob-concept-pill {
    background: var(--pill-bg); color: var(--pill-text); font-size: 10px; font-weight: 700;
    text-transform: uppercase; letter-spacing: 0.05em; padding: 3px 10px; border-radius: 12px;
    display: inline-block; margin: 0 2px;
  }
  .ob-note {
    font-size: 11px; line-height: 1.45; color: var(--text-muted);
    background: rgba(255,110,64,0.06); border-left: 2px solid var(--accent-orange);
    padding: 8px 10px; border-radius: 0 4px 4px 0; width: 100%; text-align: left;
  }

  /* Footer: progress dots + action buttons */
  .ob-footer {
    border-top: 1px solid var(--border-light); padding: 12px 16px;
    display: flex; justify-content: space-between; align-items: center;
  }
  .ob-dots { display: flex; gap: 6px; align-items: center; }
  .ob-dot-step { width: 6px; height: 6px; border-radius: 50%; background: #e2e2e2; transition: background 0.2s, width 0.2s; }
  .ob-dot-step.active { background: var(--accent-orange); width: 18px; border-radius: 3px; }
  .ob-buttons { display: flex; gap: 8px; align-items: center; }
  .ob-btn-skip {
    background: none; border: none; cursor: pointer; font-size: 12px;
    color: var(--text-muted); padding: 4px 8px; border-radius: 4px; font-family: var(--font-sans);
  }
  .ob-btn-skip:hover { color: var(--text-dark); }
  .ob-btn-primary {
    background: var(--text-dark); color: #ffffff; border: none; border-radius: 20px;
    padding: 8px 18px; font-size: 12px; font-weight: 600; cursor: pointer;
    font-family: var(--font-sans); transition: background 0.2s;
  }
  .ob-btn-primary:hover { background: var(--accent-orange-dark); }

  /* 10. Onboarding Nudge Dot — teaches the highlight action */
  #ll-nudge {
    position: fixed;
    right: 24px;
    top: 50%;
    transform: translateY(-50%);
    z-index: 2147483647;
    display: flex;
    align-items: center;
    gap: 0;
    cursor: pointer;
    pointer-events: auto;
  }
  #ll-nudge.hidden { display: none; }
  #ll-nudge.fade-out { opacity: 0; transition: opacity 0.4s ease-out; pointer-events: none; }

  .nudge-dot {
    width: 14px; height: 14px;
    background: var(--accent-orange);
    border-radius: 50%;
    flex-shrink: 0;
    position: relative;
    box-shadow: 0 0 12px rgba(255,110,64,0.4);
  }
  .nudge-dot::before {
    content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0;
    background: var(--accent-orange); border-radius: 50%;
    animation: ll-pulse-ring 2s cubic-bezier(0.455, 0.03, 0.515, 0.955) infinite;
  }
  #ll-nudge.prominent .nudge-dot::before {
    animation: ll-nudge-prominent 1s cubic-bezier(0.455, 0.03, 0.515, 0.955) 3;
  }
  @keyframes ll-nudge-prominent {
    0% { transform: scale(0.8); opacity: 1; box-shadow: 0 0 0 0 rgba(255,110,64,0.7); }
    50% { transform: scale(2.8); opacity: 0.6; box-shadow: 0 0 20px rgba(255,110,64,0.4); }
    100% { transform: scale(3.5); opacity: 0; box-shadow: 0 0 0 0 rgba(255,110,64,0); }
  }

  .nudge-tooltip {
    position: absolute;
    right: 22px;
    white-space: nowrap;
    background: var(--bg-dark);
    color: var(--text-light);
    font-family: var(--font-sans);
    font-size: 12px;
    font-weight: 500;
    padding: 8px 14px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    opacity: 0;
    transform: translateX(8px);
    transition: opacity 0.25s ease-out, transform 0.25s ease-out;
    pointer-events: none;
  }
  .nudge-tooltip::after {
    content: ''; position: absolute; top: 50%; right: -6px; transform: translateY(-50%);
    border: 6px solid transparent; border-left-color: var(--bg-dark); border-right: none;
  }
  .nudge-tooltip.visible { opacity: 1; transform: translateX(0); }
`;
shadow.appendChild(style);

// 1. Indicator
const indicator = document.createElement('div');
indicator.id = 'll-indicator';
indicator.className = 'hidden';
indicator.innerHTML = `
  <div class="ll-wave">
    <div class="ll-bar"></div><div class="ll-bar"></div><div class="ll-bar"></div><div class="ll-bar"></div>
  </div>
  <span id="ll-text">Lenny is listening...</span>
`;
shadow.appendChild(indicator);

// 2. Mic denied tooltip
const tooltip = document.createElement('div');
tooltip.id = 'll-tooltip';
tooltip.textContent = 'Microphone access denied.';
shadow.appendChild(tooltip);

// 3. Toast
const toast = document.createElement('div');
toast.id = 'll-toast';
toast.innerHTML = '<div class="toast-content"><span class="toast-icon">✕</span><span id="ll-toast-text"></span></div>';
shadow.appendChild(toast);

// 5. Postcard
const postcard = document.createElement('div');
postcard.id = 'll-postcard';
postcard.className = 'hidden';
postcard.innerHTML = `
  <div class="pc-header">
    <span class="pc-logo">lennyLive</span>
    <div class="pc-actions">
      <button id="ll-btn-mute" class="pc-btn" title="Mute">🔇</button>
      <button id="ll-btn-save" class="pc-btn" title="Save">🔖</button>
      <button id="ll-btn-dismiss" class="pc-btn" title="Dismiss">✕</button>
    </div>
  </div>
  <div class="pc-body">
    <p id="ll-pc-framing" class="pc-framing">Connecting <span id="ll-pc-niche">this topic</span> to <span id="ll-pc-pm-topic"></span>...</p>
    <div class="pc-topic" id="ll-pc-topic"></div>
    <div class="pc-quote-wrapper" id="ll-quote-wrapper">
      <p class="pc-quote" id="ll-pc-quote"></p>
      <div class="pc-fade" id="ll-quote-fade"></div>
    </div>
    <button id="ll-btn-readmore" class="pc-read-more">Read more</button>
    <div id="ll-related" class="pc-related hidden"></div>
  </div>
  <div class="pc-footer">
    <div class="pc-footer-meta">
      <span class="pc-guest" id="ll-pc-guest"></span>
      <span class="pc-episode" id="ll-pc-source"></span>
    </div>
    <a id="ll-pc-link" class="pc-source-link hidden" target="_blank" rel="noopener noreferrer">↗ Source</a>
  </div>
`;
shadow.appendChild(postcard);

// 6. Selection Dot
const selectionDot = document.createElement('div');
selectionDot.id = 'll-selection-dot';
selectionDot.innerHTML = '<div class="pulse-dot-wrapper"></div>';
shadow.appendChild(selectionDot);

// 7. Badge Pill (replaces Write+Pause Dot + Questions Panel)
const badgePill = document.createElement('div');
badgePill.id = 'll-badge-pill';
badgePill.innerHTML = `
  <div class="ll-chips-panel" id="ll-chips-panel"></div>
  <button class="ll-badge-trigger" id="ll-badge-trigger" type="button">
    <span class="ll-badge-dot" id="ll-badge-dot"></span>
    <span class="ll-badge-text" id="ll-badge-text">Lenny has thoughts</span>
    <span class="ll-badge-arrow">→</span>
  </button>
`;
shadow.appendChild(badgePill);

// 8. Onboarding Panel (slides into position on first PM highlight)
const onboardingPanel = document.createElement('div');
onboardingPanel.id = 'll-onboarding';
onboardingPanel.className = 'hidden';
onboardingPanel.innerHTML = `
  <div class="ob-header">
    <span class="ob-logo">lennyLive</span>
    <button class="ob-close" id="ll-ob-close" type="button">✕</button>
  </div>
  <div class="ob-body">
    <div class="ob-slide" id="ll-ob-slide-1">
      <div class="ob-pulse-large"></div>
      <p class="ob-headline">Lenny is finding something.</p>
      <p class="ob-text" id="ll-ob-body-text">Analyzing your highlight. Lenny is cross-referencing this against frameworks and stories from 300+ top product leaders.</p>
    </div>
    <div class="ob-slide hidden" id="ll-ob-slide-2">
      <div class="ob-kbd-mock">
        <div class="ob-kbd">
          <span class="ob-key">Ctrl</span>
          <span class="ob-key-sep">+</span>
          <span class="ob-key">Ctrl</span>
        </div>
        <span class="ob-kbd-label">double-tap to activate</span>
      </div>
      <p class="ob-headline">Ask Lenny anything.</p>
      <p class="ob-text">Double-tap <strong>Ctrl</strong>, speak your question, and Lenny responds in seconds — grounded in real guest stories and episodes.</p>
      <p class="ob-note">Chrome will ask for microphone access. This lets Lenny hear your question.</p>
    </div>
  </div>
  <div class="ob-footer">
    <div class="ob-dots">
      <div class="ob-dot-step active" id="ll-ob-dot-1"></div>
      <div class="ob-dot-step" id="ll-ob-dot-2"></div>
    </div>
    <div class="ob-buttons">
      <button class="ob-btn-skip hidden" id="ll-ob-skip" type="button">Skip</button>
      <button class="ob-btn-primary" id="ll-ob-next" type="button">Next →</button>
    </div>
  </div>
`;
shadow.appendChild(onboardingPanel);

// 9. Onboarding Nudge Dot (teaches the highlight action on first visit)
const nudge = document.createElement('div');
nudge.id = 'll-nudge';
nudge.className = 'hidden';
nudge.innerHTML = `
  <span class="nudge-tooltip" id="ll-nudge-tooltip">✨ Highlight any text to get PM insights from Lenny.</span>
  <div class="nudge-dot"></div>
`;
shadow.appendChild(nudge);

// ─── UI Helper Functions ──────────────────────────────────────────────────────

function showIndicator(mode) {
  // mode: 'listening' | 'thinking' | 'loading'
  const text = shadow.getElementById('ll-text');
  indicator.classList.remove('hidden', 'loading');
  if (mode === 'listening') {
    text.textContent = 'Lenny is listening...';
  } else if (mode === 'thinking') {
    text.textContent = 'Lenny is thinking...';
  } else if (mode === 'loading') {
    indicator.classList.add('loading');
    text.textContent = 'Lenny is thinking...'; // visible but shimmer covers it
  }
}

function hideIndicator() {
  indicator.classList.add('hidden');
}

function showMicDeniedTooltip() {
  tooltip.classList.add('visible');
  setTimeout(() => tooltip.classList.remove('visible'), 4000);
}

// ─── Onboarding Nudge ─────────────────────────────────────────────────────────

let nudgeAutoCollapseTimer = null;

function showNudge() {
  nudge.classList.remove('hidden', 'fade-out');
  const tooltip = shadow.getElementById('ll-nudge-tooltip');
  // Auto-expand tooltip for 3s on first appearance
  tooltip.classList.add('visible');
  nudgeAutoCollapseTimer = setTimeout(() => {
    tooltip.classList.remove('visible');
  }, 3000);
}

function hideNudge(instant = false) {
  clearTimeout(nudgeAutoCollapseTimer);
  if (instant) {
    // Remove immediately — no fade, no delay
    nudge.classList.add('hidden');
    nudge.classList.remove('fade-out');
  } else {
    nudge.classList.add('fade-out');
    setTimeout(() => nudge.classList.add('hidden'), 400);
  }
}

function pulseNudge() {
  nudge.classList.add('prominent');
  const tooltip = shadow.getElementById('ll-nudge-tooltip');
  tooltip.classList.add('visible');
  // After 3 prominent pulses (~3s), return to normal
  setTimeout(() => {
    nudge.classList.remove('prominent');
    tooltip.classList.remove('visible');
  }, 3000);
}

// Hover: re-expand tooltip
nudge.addEventListener('mouseenter', () => {
  clearTimeout(nudgeAutoCollapseTimer);
  shadow.getElementById('ll-nudge-tooltip').classList.add('visible');
});
nudge.addEventListener('mouseleave', () => {
  shadow.getElementById('ll-nudge-tooltip').classList.remove('visible');
});

// Inject nudge on page load if user has not onboarded
chrome.storage.local.get(['hasOnboarded'], (data) => {
  if (!data.hasOnboarded) {
    showNudge();
    console.log('[LennyLive] Nudge dot shown — first-time user');
  }
});

// ─── Page-Level Semantic Classification ──────────────────────────────────────
// Classify the page once on load via Groq. Result cached as boolean.
// Allows selection dot on ANY highlight on PM-relevant pages.

function schedulePageClassification() {
  setTimeout(() => {
    const pageContent = extractPageContext();
    if (!pageContent || pageContent.length < 50) return;
    chrome.runtime.sendMessage({ type: 'CLASSIFY_PAGE', pageContent });
    lastClassifiedUrl = location.href;
    console.log('[LennyLive] Page classification requested');
  }, 2000);
}
schedulePageClassification();

// SPA navigation detection — re-classify when URL changes
const _origPushState = history.pushState;
history.pushState = function() {
  _origPushState.apply(this, arguments);
  if (location.href !== lastClassifiedUrl) {
    pageIsPMContext = null;
    schedulePageClassification();
  }
};
window.addEventListener('popstate', () => {
  if (location.href !== lastClassifiedUrl) {
    pageIsPMContext = null;
    schedulePageClassification();
  }
});

// ─── Postcard ─────────────────────────────────────────────────────────────────

let autoDismissTimer = null;
let currentInsight = null; // held for Save button

function showPostcard(insight, relatedInsights = []) {
  currentInsight = insight;
  const pc = shadow.getElementById('ll-postcard');
  hideIndicator(); // always hide indicator — they share bottom-right corner
  // Forcefully clear ALL ambient UI — widget and dots must never coexist on screen
  hideSelectionDot();
  hideNudge(true);
  hideAllAmbientUI();
  pc.classList.remove('ll-postcard-hiding'); // cancel any in-flight exit animation

  // Populate content
  shadow.getElementById('ll-pc-topic').textContent = insight.topic;
  shadow.getElementById('ll-pc-quote').textContent = insight.pull_quote;
  shadow.getElementById('ll-pc-guest').textContent = insight.guest_name;
  const isNewsletter = insight.guest_name === 'Lenny Rachitsky';
  shadow.getElementById('ll-pc-source').textContent = isNewsletter
    ? 'Newsletter — lennysnewsletter.com'
    : 'Ep: ' + insight.episode_title;

  // Source link — podcast opens at exact timestamp, newsletter opens article
  const linkEl = shadow.getElementById('ll-pc-link');
  if (insight.youtube_url) {
    const url = (!isNewsletter && insight.timestamp_secs)
      ? `${insight.youtube_url}?t=${insight.timestamp_secs}`
      : insight.youtube_url;
    linkEl.href = url;
    linkEl.textContent = isNewsletter ? '↗ Read' : '↗ Watch';
    linkEl.classList.remove('hidden');
  } else {
    linkEl.classList.add('hidden');
  }

  const framingEl = shadow.getElementById('ll-pc-framing');
  if (insight.abstracted) { 
    framingEl.style.display = 'block';
    shadow.getElementById('ll-pc-pm-topic').textContent = insight.topic.toLowerCase();
  } else {
    framingEl.style.display = 'none';
  }

  // Read more expand logic reset
  shadow.getElementById('ll-quote-wrapper').classList.remove('expanded');
  shadow.getElementById('ll-btn-readmore').textContent = 'Read more';
  if (insight.pull_quote.length < 150) {
    shadow.getElementById('ll-btn-readmore').classList.add('hidden');
    shadow.getElementById('ll-quote-fade').style.display = 'none';
  } else {
    shadow.getElementById('ll-btn-readmore').classList.remove('hidden');
    shadow.getElementById('ll-quote-fade').style.display = 'block';
  }

  // Populate related insights (hidden until "Read more" is clicked)
  const relatedEl = shadow.getElementById('ll-related');
  relatedEl.classList.add('hidden');
  relatedEl.innerHTML = '';
  if (relatedInsights && relatedInsights.length > 0) {
    const header = document.createElement('div');
    header.className = 'pc-related-header';
    header.textContent = 'Related insights';
    relatedEl.appendChild(header);

    relatedInsights.forEach(r => {
      const isNews = r.guest_name === 'Lenny Rachitsky';
      const url = (!isNews && r.timestamp_secs)
        ? `${r.youtube_url}?t=${r.timestamp_secs}`
        : r.youtube_url;
      const snippet = r.pull_quote.length > 120
        ? r.pull_quote.slice(0, 120).replace(/\s+\S*$/, '') + '…'
        : r.pull_quote;

      const item = document.createElement('div');
      item.className = 'pc-related-item';
      item.innerHTML = `
        <div class="pc-related-topic">${r.topic}</div>
        <div class="pc-related-quote">${snippet}</div>
        <div class="pc-related-meta">
          <span class="pc-related-guest">${r.guest_name}</span>
          ${url ? `<a class="pc-related-link" href="${url}" target="_blank" rel="noopener noreferrer">${isNews ? '↗ Read' : '↗ Watch'}</a>` : ''}
        </div>
      `;
      relatedEl.appendChild(item);
    });
  }

  // Set mute default synchronously so audio guard works even before storage returns
  pc.dataset.muted = 'false';
  updateMuteButton(false);

  // Update from persisted preference (async — completes long before AUDIO arrives)
  chrome.storage.local.get(['voiceMuted'], (result) => {
    if (chrome.runtime.lastError) return;
    const muted = !!result.voiceMuted;
    pc.dataset.muted = String(muted);
    updateMuteButton(muted);
  });

  // Show card and start auto-dismiss
  pc.classList.remove('hidden');
  clearTimeout(autoDismissTimer);
  autoDismissTimer = setTimeout(hidePostcard, 30000);

  // +5 XP on insight delivery (PRD v2 §2.2)
  chrome.storage.local.get(['knowledge_score'], (s) => {
    if (!chrome.runtime.lastError) {
      chrome.storage.local.set({ knowledge_score: (s.knowledge_score || 0) + 5 });
    }
  });
}

function updateStreak() {
  const today = new Date().toISOString().split('T')[0];
  chrome.storage.local.get(['streak', 'lastActiveDate', 'longest_streak', 'knowledge_score'], (data) => {
    if (chrome.runtime.lastError) return;
    const last = data.lastActiveDate;
    let streak = data.streak || 0;
    if (last !== today) {
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      streak = (last === yesterday) ? streak + 1 : 1;
      const longest = Math.max(streak, data.longest_streak || 0);
      const streakBonus = streak * 2;
      const newScore = (data.knowledge_score || 0) + streakBonus;
      chrome.storage.local.set({ streak, lastActiveDate: today, longest_streak: longest, knowledge_score: newScore });
    }
  });
}

function hidePostcard() {
  clearTimeout(autoDismissTimer);
  const pc = shadow.getElementById('ll-postcard');
  if (pc.classList.contains('hidden')) return; // already hidden — no-op
  pc.classList.add('ll-postcard-hiding');
  // Duration must match --ll-anim-duration (0.2s = 200ms)
  // If you change --ll-anim-duration, update this timeout to match.
  setTimeout(() => {
    pc.classList.remove('ll-postcard-hiding');
    pc.classList.add('hidden');
  }, 200);
}

function updateMuteButton(muted) {
  const btn = shadow.getElementById('ll-btn-mute');
  if (btn) btn.textContent = muted ? '🔊 Unmute' : '🔇 Mute';
}

let currentAudio = null; // held so mute button can stop in-flight audio

function stopCurrentAudio() {
  if (currentAudio) {
    currentAudio.pause();
    currentAudio = null;
  }
}

function playAudio(base64) {
  const pc = shadow.getElementById('ll-postcard');
  if (pc && pc.dataset.muted === 'true') return;

  stopCurrentAudio(); // stop any previous clip before starting a new one

  // data: URIs are blocked by strict CSP on sites like Notion.
  // Convert to a Blob and use a blob: URL — allowed by "media-src blob:".
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  const blob = new Blob([bytes], { type: 'audio/mpeg' });
  const url = URL.createObjectURL(blob);

  const audio = new Audio(url);
  currentAudio = audio;
  audio.play()
    .then(() => {
      audio.onended = () => {
        URL.revokeObjectURL(url);
        if (currentAudio === audio) currentAudio = null;
      };
    })
    .catch(err => {
      URL.revokeObjectURL(url);
      if (currentAudio === audio) currentAudio = null;
      console.warn('[LennyLive] Audio playback failed:', err.message);
    });
}

// ─── Postcard Event Listeners (set up once at load time) ──────────────────────

shadow.getElementById('ll-btn-readmore').addEventListener('click', (e) => {
  const wrapper = shadow.getElementById('ll-quote-wrapper');
  const relatedEl = shadow.getElementById('ll-related');
  if (wrapper.classList.contains('expanded')) {
    wrapper.classList.remove('expanded');
    relatedEl.classList.add('hidden');
    e.target.textContent = 'Read more';
  } else {
    wrapper.classList.add('expanded');
    // Show related only if there are items to display
    if (relatedEl.children.length > 0) {
      relatedEl.classList.remove('hidden');
    }
    e.target.textContent = 'Show less';
  }
});

shadow.getElementById('ll-postcard').addEventListener('mouseenter', () => {
  clearTimeout(autoDismissTimer);
});

shadow.getElementById('ll-postcard').addEventListener('mouseleave', () => {
  clearTimeout(autoDismissTimer);
  autoDismissTimer = setTimeout(hidePostcard, 30000);
});

shadow.getElementById('ll-btn-dismiss').addEventListener('click', () => {
  clearTimeout(autoDismissTimer);
  stopCurrentAudio();
  hidePostcard();
});

shadow.getElementById('ll-btn-mute').addEventListener('click', () => {
  const pc = shadow.getElementById('ll-postcard');
  const newMuted = pc.dataset.muted !== 'true';
  pc.dataset.muted = String(newMuted);
  updateMuteButton(newMuted);
  // Stop any currently-playing audio immediately when muting
  if (newMuted) stopCurrentAudio();
  chrome.storage.local.set({ voiceMuted: newMuted }, () => {
    if (chrome.runtime.lastError) {
      console.warn('[LennyLive] voiceMuted save failed:', chrome.runtime.lastError.message);
    }
  });
});

shadow.getElementById('ll-btn-save').addEventListener('click', () => {
  if (!currentInsight) return;
  const entry = {
    topic:         currentInsight.topic,
    pull_quote:    currentInsight.pull_quote,
    insight:       currentInsight.insight || '',
    guest_name:    currentInsight.guest_name,
    episode_title: currentInsight.episode_title,
    youtube_url:   currentInsight.youtube_url,
    timestamp_secs: currentInsight.timestamp_secs,
    saved_at:      new Date().toISOString(),
  };
  chrome.storage.local.get(['savedInsights', 'knowledge_score', 'topicCounts'], (result) => {
    if (chrome.runtime.lastError) {
      console.warn('[LennyLive] Save read failed:', chrome.runtime.lastError.message);
      return;
    }
    const existing = result.savedInsights || [];

    // Duplicate check — match on pull_quote + guest_name (PRD v2 §1.3)
    const isDuplicate = existing.some(
      e => e.pull_quote === entry.pull_quote && e.guest_name === entry.guest_name
    );
    if (isDuplicate) {
      const btn = shadow.getElementById('ll-btn-save');
      if (btn) { btn.textContent = 'Already saved'; setTimeout(() => { btn.textContent = '🔖 Save'; }, 2000); }
      return;
    }

    existing.push(entry);

    // Update topicCounts for PM Knowledge Map (PRD v2 §2.3)
    const topicCounts = result.topicCounts || {};
    const topic = entry.topic || 'PM Insights';
    topicCounts[topic] = (topicCounts[topic] || 0) + 1;

    // Micro-celebration toast text (PRD v2 §1.2)
    const totalSaves = existing.length;
    const topicCount = topicCounts[topic];
    let toastText = `✓ Saved to ${topic}`;
    if (totalSaves === 1) {
      toastText = 'Your PM library starts here.';
    } else if (topicCount === 1) {
      toastText = `New topic: ${topic}`;
    } else if (topicCount === 5) {
      toastText = `${topic} explored — 5 insights deep.`;
    } else if (totalSaves === 10) {
      toastText = '10 insights. You\'re building a real PM library.';
    }

    chrome.storage.local.set({ savedInsights: existing, topicCounts, knowledge_score: (result.knowledge_score || 0) + 15 }, () => {
      if (chrome.runtime.lastError) {
        console.warn('[LennyLive] Save write failed:', chrome.runtime.lastError.message);
      } else {
        console.log('[LennyLive] Insight saved:', entry.topic, '| topicCounts:', topicCounts);
        const btn = shadow.getElementById('ll-btn-save');
        if (btn) {
          btn.textContent = toastText;
          setTimeout(() => { btn.textContent = '🔖 Save'; }, toastText.length > 20 ? 3000 : 2000);
        }
      }
    });
  });
});

// ─── Onboarding Event Listeners ────────────────────────────────────────────────

shadow.getElementById('ll-ob-next').addEventListener('click', () => {
  if (onboardingSlide === 1) {
    // Advance to slide 2
    onboardingSlide = 2;
    shadow.getElementById('ll-ob-slide-1').classList.add('hidden');
    shadow.getElementById('ll-ob-slide-2').classList.remove('hidden');
    shadow.getElementById('ll-ob-dot-1').classList.remove('active');
    shadow.getElementById('ll-ob-dot-2').classList.add('active');
    shadow.getElementById('ll-ob-skip').classList.remove('hidden');
    shadow.getElementById('ll-ob-next').textContent = 'Get Started →';
  } else {
    // Get Started on slide 2 — dismiss
    onboardingSlide = 1;
    dismissOnboarding();
  }
});

shadow.getElementById('ll-ob-skip').addEventListener('click', () => {
  onboardingSlide = 1;
  dismissOnboarding();
});

shadow.getElementById('ll-ob-close').addEventListener('click', () => {
  onboardingSlide = 1;
  dismissOnboarding();
});

// ─── State Machine ────────────────────────────────────────────────────────────
// States: idle | listening | loading
// Transitions: idle → listening → loading → idle
// Errors / Esc / timeout always return to idle.

let state = 'idle';

// ─── Ambient Detection State ──────────────────────────────────────────────────
// Separate from the voice state machine (idle|listening|loading).
// Tracks which ambient UI element is currently active.

let ambientState = 'none'; // 'none' | 'selection-dot' | 'write-pause-dot' | 'questions-panel'

// ─── Onboarding State ─────────────────────────────────────────────────────────
let isOnboarding = false;           // true while onboarding panel is visible
let onboardingCancelled = false;    // true if voice fired during onboarding — discard pending RAG
let pendingOnboardingResult = null; // { insight, relatedInsights } | null — buffered RAG result
let onboardingSelection = '';       // selected text captured before window.getSelection() is cleared
let onboardingSlide = 1; // tracks which slide is currently visible (1 or 2)

// ─── Page-Level Semantic Classification ──────────────────────────────────────
let pageIsPMContext = null; // null=unknown, true=PM page, false=not PM
let lastClassifiedUrl = '';

// Write+pause sensor state
let lastPrintableKeystroke = 0;       // timestamp of last printable keydown
let lastEagerFetchBlockContent = '';  // blockContent captured at eager fetch time
let pendingQuestions = null;          // { keyword, questions, blockContent, timestamp } | null
let eagerFetchTimer = null;           // 1.5s timer → triggers Groq fetch
let dotAppearTimer = null;            // 3.5s timer → shows write+pause dot
let activeSensorElement = null;       // element the write+pause sensor is currently attached to
// API cost reduction — three gates in triggerEagerFetch
let lastEagerFetchParagraphHash = '';   // first 80 chars of last submitted paragraph
const sessionChipsCache = new Map();   // conceptKey → {keyword, questions} — survives pendingQuestions=null
let lastKnownConcept = null; // concept from last successful QUESTIONS_READY — persists across keystrokes

// Reading sensor gate
const pageLoadTime = Date.now();      // used to enforce 20s minimum before reading sensor fires

// Returns true if the user is actively editing (typing in an input/contenteditable).
// Used to gate the reading sensor and write+pause sensor.
//
// IMPORTANT: Uses active.isContentEditable (not [contenteditable] attribute selector).
// [contenteditable] matches contenteditable="false" on Notion read-only blocks — false positives.
// isContentEditable is the DOM's computed boolean that correctly handles inheritance.
function isUserEditing() {
  const active = document.activeElement;
  if (!active) return false;
  if (active.isContentEditable || active.matches('input, textarea')) return true;
  // Google Docs uses a canvas editor — activeElement is not contenteditable.
  // Fall back to: has the user pressed a printable key in the last 5 seconds?
  if (location.hostname === 'docs.google.com' && Date.now() - lastPrintableKeystroke < 5000) return true;
  return false;
}

// ─── Element-First Sensor Attachment ─────────────────────────────────────────
// Attaches the write+pause keydown listener to the specific focused element.
// This replaces the global keydown approach — sensor follows the cursor, not the URL.

function onSensorKeydown(e) {
  // Only track printable characters — ignore Ctrl, Shift, Alt, arrows, etc.
  if (e.key.length !== 1 || e.ctrlKey || e.metaKey || e.altKey) return;

  lastPrintableKeystroke = Date.now();

  // User is typing — cancel any pending fetch and reset
  clearTimeout(eagerFetchTimer);
  clearTimeout(dotAppearTimer);
  pendingQuestions = null;
  hideWritePauseDot(); // no-op if not visible

  // Schedule fresh eager fetch 1.5s from now
  eagerFetchTimer = setTimeout(triggerEagerFetch, 1500);
}

// Paste handler — Cmd+V is filtered by onSensorKeydown (metaKey guard), so paste
// events never start the eager fetch timer. Handle separately.
function onSensorPaste() {
  lastPrintableKeystroke = Date.now();
  clearTimeout(eagerFetchTimer);
  clearTimeout(dotAppearTimer);
  pendingQuestions = null;
  hideWritePauseDot();
  // Give the DOM time to reflect the pasted content before reading it
  eagerFetchTimer = setTimeout(triggerEagerFetch, 1500);
}

function attachWritePauseSensor(el) {
  // Detach from previous element first (covers focus-shift without blur)
  detachWritePauseSensor();
  activeSensorElement = el;
  el.addEventListener('keydown', onSensorKeydown);
  el.addEventListener('paste', onSensorPaste);
  console.log('[LennyLive] Write+pause sensor attached to:', el.tagName, el.id || el.className.slice(0, 30));
}

function detachWritePauseSensor() {
  if (activeSensorElement) {
    activeSensorElement.removeEventListener('keydown', onSensorKeydown);
    activeSensorElement.removeEventListener('paste', onSensorPaste);
    activeSensorElement = null;
    // Cancel any pending timers — user left the field
    clearTimeout(eagerFetchTimer);
    clearTimeout(dotAppearTimer);
    console.log('[LennyLive] Write+pause sensor detached');
  }
}

// focusin fires when any element in the document gains focus (bubbles up).
// We only care about contenteditable divs and form inputs.
document.addEventListener('focusin', (e) => {
  const el = e.target;
  if (!el) return;
  if (el.isContentEditable || el.matches('input, textarea')) {
    attachWritePauseSensor(el);
  }
});

// focusout fires when focus leaves any element.
// Detach sensor — user is no longer typing in a monitored field.
// Do NOT hide the badge pill here — user needs to be able to click it even after
// leaving the text field. Badge persists until clicked, dismissed, or new typing starts.
document.addEventListener('focusout', () => {
  detachWritePauseSensor();
});

// ─── Ambient UI Stubs (implemented by UI agent) ───────────────────────────────

function showSelectionDot(rect) {
  // Capture selection NOW (before mousedown clears it)
  const selectedText = window.getSelection()?.toString().trim() ?? '';
  if (!selectedText) return;
  
  // Bottom-right anchor (Medium/Notion pattern): sit just below the last line
  // of highlighted text, right-aligned with the selection's right edge.
  // position:fixed uses viewport coords — rect from getBoundingClientRect() is
  // already viewport-relative, no scrollX/scrollY offset needed.
  // Dot is 14px wide (pulse-dot-wrapper) — align its right edge with rect.right.
  // Clamp to viewport with 40px padding (PRD v2 §4.4)
  const dotX = Math.min(rect.right - 14, window.innerWidth - 40);
  const dotY = Math.min(rect.bottom + 5, window.innerHeight - 40);
  selectionDot.style.left = `${Math.max(8, dotX)}px`;
  selectionDot.style.top = `${Math.max(8, dotY)}px`;
  selectionDot.classList.add('visible');
  
  // Important: mousedown must preventDefault to preserve selection
  selectionDot.onmousedown = (e) => {
    e.preventDefault(); 
    e.stopPropagation();
  };
  selectionDot.onclick = () => {
    updateStreak(); // Streak fires on activation, not success
    // Truncate to 2000 chars before sending — embedding API handles this fine,
    // and full-page selections can be arbitrarily long.
    chrome.runtime.sendMessage({ type: 'QUERY', transcript: '', selection: selectedText.slice(0, 2000), pageContext: '' });
    hideSelectionDot();
  };
  
  if (ambientState !== 'selection-dot') ambientState = 'selection-dot';
}

function hideSelectionDot() {
  selectionDot.classList.remove('visible');
  if (ambientState === 'selection-dot') ambientState = 'none';
}

// Show badge pill — either loading state or ready state with question count
function showWritePauseDot(mode = 'ready') {
  const dot = shadow.getElementById('ll-badge-dot');
  const text = shadow.getElementById('ll-badge-text');
  const trigger = shadow.getElementById('ll-badge-trigger');

  if (mode === 'loading') {
    dot.className = 'll-badge-dot loading';
    text.textContent = 'Lenny is thinking...';
    trigger.onclick = null; // disabled while loading
  } else {
    // mode === 'ready'
    dot.className = 'll-badge-dot';
    const keyword = pendingQuestions?.keyword || '';
    const count = pendingQuestions?.questions?.length || 3;
    text.textContent = `${count} pattern${count !== 1 ? 's' : ''} on ${keyword}`;
    trigger.onclick = () => {
      if (ambientState === 'write-pause-dot' && pendingQuestions) {
        // Check if paragraph changed since questions were generated — re-fetch if so
        const currentHash = extractPageContext().slice(0, 80);
        if (currentHash !== lastEagerFetchParagraphHash) {
          console.log('[LennyLive] Badge clicked — paragraph drifted, re-fetching');
          showWritePauseDot('loading');
          const blockContent = extractPageContext();
          // Use existing concept as hint — Groq will re-identify if paragraph has shifted
          const keyword2 = pendingQuestions.keyword || '';
          pendingQuestions = null;
          lastEagerFetchParagraphHash = currentHash;
          lastEagerFetchBlockContent = blockContent;
          chrome.runtime.sendMessage({ type: 'GENERATE_QUESTIONS', keyword: keyword2, blockContent });
          return;
        }
        showChipsPanel(pendingQuestions.questions);
      }
    };
  }

  badgePill.classList.add('visible');
  ambientState = 'write-pause-dot';
}

function hideWritePauseDot() {
  badgePill.classList.remove('visible');
  shadow.getElementById('ll-chips-panel').classList.remove('visible');
  if (ambientState === 'write-pause-dot') ambientState = 'none';
}

function showChipsPanel(questions) {
  ambientState = 'questions-panel';
  const panel = shadow.getElementById('ll-chips-panel');

  // Build header with static innerHTML (no user-controlled variables — safe)
  panel.innerHTML = `
    <div class="ll-chips-header">
      <span class="ll-chips-title">What Lenny would ask</span>
      <button class="ll-chips-close" id="ll-chips-close-btn" type="button">✕</button>
    </div>
    <div class="ll-chips-list" id="ll-chips-list-inner"></div>
  `;

  // Build chips via DOM API — textContent prevents XSS from Groq-sourced question strings
  const list = panel.querySelector('#ll-chips-list-inner');
  questions.forEach((q, i) => {
    const btn = document.createElement('button');
    btn.className = 'll-chip-btn';
    btn.dataset.idx = i;
    btn.type = 'button';
    const textSpan = document.createElement('span');
    textSpan.className = 'll-chip-btn-text';
    textSpan.textContent = q;
    const arrowSpan = document.createElement('span');
    arrowSpan.className = 'll-chip-btn-arrow';
    arrowSpan.textContent = '→';
    btn.append(textSpan, arrowSpan);
    list.appendChild(btn);
  });

  panel.classList.add('visible');

  shadow.getElementById('ll-chips-close-btn').onclick = hideAllAmbientUI;

  const chips = panel.querySelectorAll('.ll-chip-btn');
  chips.forEach(chip => {
    chip.onclick = () => {
      const idx = parseInt(chip.getAttribute('data-idx'), 10);
      fireQuestionQuery(questions[idx]);
    };
  });
}

// Called when QUESTIONS_READY arrives and dot is already showing in loading state
function updateWritePauseDotReady() {
  if (!pendingQuestions) return;
  showWritePauseDot('ready');
}

function hideAllAmbientUI() {
  hideSelectionDot();
  hideWritePauseDot(); // handles badgePill + chips panel
  clearTimeout(eagerFetchTimer);
  clearTimeout(dotAppearTimer);
  pendingQuestions = null;

  if (ambientState === 'questions-panel') {
    const panel = shadow.getElementById('ll-chips-panel');
    panel.classList.remove('visible');
    ambientState = 'none';
  }
}

// Called by the UI agent when a question chip is tapped.
// Fires the QUERY message with the chip text as transcript.
function fireQuestionQuery(questionText) {
  if (!pendingQuestions) return;
  // Spec requires 60s expiry — stale questions are no longer contextually relevant
  if (Date.now() - pendingQuestions.timestamp > 60000) {
    hideAllAmbientUI();
    return;
  }
  const blockContent = pendingQuestions.blockContent || '';
  hideAllAmbientUI();
  chrome.runtime.sendMessage({
    type: 'QUERY',
    transcript: questionText,
    selection: '',
    pageContext: blockContent,
  });
  console.log('[LennyLive] Question chip fired:', questionText);
}

// ─── Ping Tone (Web Audio API) ────────────────────────────────────────────────
// Double-tap Ctrl is a keydown event — qualifies as a user gesture for autoplay.

function playPing() {
  try {
    const ctx = new AudioContext();
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = 880;
    osc.type = 'sine';
    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.4);
    osc.onended = () => ctx.close();
  } catch (err) {
    console.log('[LennyLive] Ping audio failed (autoplay blocked):', err.message);
    // Fail silently — activation continues without sound
  }
}

// ─── Page Context Extraction ──────────────────────────────────────────────────
// Captures the semantic text the user is actually reading/writing.
// Avoids document.body.innerText — polluted with nav bars, sidebars, menus.
// Three-priority cascade: active cursor block → semantic container → title fallback.

function extractPageContext() {
  const MAX_CHARS = 500;

  // Priority 1: Active cursor block
  // If the user's cursor is inside a contenteditable, textarea, or input,
  // that element contains exactly what they're writing/editing right now.
  const active = document.activeElement;
  if (active && active !== document.body) {
    const tag = active.tagName.toLowerCase();
    const isEditable = active.isContentEditable || tag === 'textarea' || tag === 'input';
    if (isEditable) {
      let text = (active.innerText || active.value || '').trim();
      // If the block is very short, grab the parent's text for more context
      if (text.length < 100 && active.parentElement) {
        const parentText = (active.parentElement.innerText || '').trim();
        if (parentText.length > text.length) text = parentText;
      }
      if (text.length > 0) {
        console.log('[LennyLive] pageContext: active cursor block');
        return text.slice(0, MAX_CHARS);
      }
    }
  }

  // Priority 2: Semantic container
  // article, main, or [role="main"] contains the page's primary content.
  // Avoids nav/sidebar/footer noise.
  const container = document.querySelector('article, main, [role="main"]');
  if (container) {
    const text = (container.innerText || '').trim();
    if (text.length > 0) {
      console.log('[LennyLive] pageContext: semantic container');
      return text.slice(0, MAX_CHARS);
    }
  }

  // Priority 3: Title fallback
  // Last resort — page title is better than nothing (e.g. canvas-rendered pages).
  const title = document.title.trim();
  if (title) {
    console.log('[LennyLive] pageContext: title fallback');
    return title.slice(0, MAX_CHARS);
  }

  return ''; // no context available
}

// ─── Toast ────────────────────────────────────────────────────────────────────

let toastTimer = null;

function showToast(message, durationMs = 3000) {
  clearTimeout(toastTimer);
  const t = shadow.getElementById('ll-toast');
  shadow.getElementById('ll-toast-text').textContent = message;
  t.classList.remove('fading');
  t.classList.add('visible');

  toastTimer = setTimeout(() => {
    t.classList.add('fading');
    setTimeout(() => t.classList.remove('visible', 'fading'), 150);
  }, durationMs);
}

// Friendly ascending bloop — played on chitchat/non-PM rejection.
// Two tones: low → high, conveys "acknowledged but redirecting".
function playBloop() {
  try {
    const ctx = new AudioContext();
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    [[440, 0], [660, 0.12]].forEach(([freq, delay]) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sine';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.18, ctx.currentTime + delay);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + 0.25);
      osc.start(ctx.currentTime + delay);
      osc.stop(ctx.currentTime + delay + 0.25);
    });
    setTimeout(() => ctx.close(), 600);
  } catch (_) {}
}

// Soft descending bump — played on genuine no_results (silence, off-topic).
// Single low tone: conveys "nothing found, try again".
function playBump() {
  try {
    const ctx = new AudioContext();
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = 'sine';
    osc.frequency.setValueAtTime(300, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(180, ctx.currentTime + 0.3);
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.3);
    osc.onended = () => ctx.close();
  } catch (_) {}
}

// ─── Selection Capture + Keyboard Handler ────────────────────────────────────

let lastCtrlPress = 0;
let currentSelection = '';

document.addEventListener('keydown', (e) => {
  if (e.key === 'Control') {
    const now = Date.now();

    if (state === 'idle' && now - lastCtrlPress < 300) {
      // Double-tap Ctrl: capture selection at this moment, then activate
      currentSelection = window.getSelection().toString().trim().slice(0, 500);
      activateLennyLive();
    } else if (state === 'listening') {
      // Single tap during listening: stop capture immediately
      stopListening();
    }

    lastCtrlPress = now; // always update, regardless of state
  }

  if (e.key === 'Escape') {
    hideAllAmbientUI();   // always clear ambient UI on Escape
    if (state === 'listening' || state === 'loading') {
      cancelLennyLive();
    }
    // Also dismiss postcard if it's visible
    const pc = shadow.getElementById('ll-postcard');
    if (pc && !pc.classList.contains('hidden')) {
      stopCurrentAudio();
      hidePostcard();
    }
  }

});

// ─── Write+Pause Eager Fetch ──────────────────────────────────────────────────

// Called 1.5s after the last printable keystroke.
// Fires Groq silently to pre-generate question chips before the dot appears.
// ─── Write+Pause Eager Fetch ──────────────────────────────────────────────────
// Called 1.5s after the last printable keystroke in a monitored element.
// Three local gates run before any Groq call:
//   Gate 1: 40-word minimum — short messages won't trigger
//   Gate 2: Paragraph hash cache — same paragraph = serve cached chips
//   Gate 3: Session concept dedup — same concept this session = serve cached chips
// No keyword gate — Groq owns PM detection for write+pause.
function triggerEagerFetch() {
  if (state !== 'idle') return;          // don't interrupt active voice session

  // Extract paragraph — two-level: cursor block first, semantic container fallback
  const blockContent = extractPageContext();
  if (!blockContent) return;

  // Gate 1: 40-word minimum — short messages are conversational, not PM work
  const wordCount = blockContent.trim().split(/\s+/).filter(w => w.length > 0).length;
  if (wordCount < 40) return;

  // Gate 2: same paragraph hash — skip
  const paragraphHash = blockContent.slice(0, 80);
  if (paragraphHash === lastEagerFetchParagraphHash) {
    // Restore cached chips if available (from prior Groq call for this paragraph)
    if (lastKnownConcept) {
      const cached = sessionChipsCache.get(lastKnownConcept);
      if (cached) {
        pendingQuestions = { ...cached, blockContent, timestamp: Date.now() };
        console.log('[LennyLive] Write+pause: paragraph unchanged — restoring cached chips');
        dotAppearTimer = setTimeout(() => { if (state !== 'idle') return; showWritePauseDot('ready'); }, 500);
      }
    }
    return;
  }

  // Gate 3: session concept dedup — same concept this session = serve cached chips
  if (lastKnownConcept && sessionChipsCache.has(lastKnownConcept)) {
    const cached = sessionChipsCache.get(lastKnownConcept);
    pendingQuestions = { ...cached, blockContent, timestamp: Date.now() };
    lastEagerFetchParagraphHash = paragraphHash;
    lastEagerFetchBlockContent = blockContent;
    console.log('[LennyLive] Write+pause: concept cached — restoring chips');
    dotAppearTimer = setTimeout(() => { if (state !== 'idle') return; showWritePauseDot('ready'); }, 500);
    return;
  }

  // All gates passed — proceed to Groq fetch
  lastEagerFetchParagraphHash = paragraphHash;
  lastEagerFetchBlockContent = blockContent;
  // sessionChipsCache updated in QUESTIONS_READY happy path after Groq responds

  console.log('[LennyLive] Write+pause: sending to Groq for concept detection | words:', wordCount);
  chrome.runtime.sendMessage({ type: 'GENERATE_QUESTIONS', keyword: '', blockContent });

  // Schedule dot appearance 2s from now (= 3.5s total from last keystroke)
  dotAppearTimer = setTimeout(() => {
    if (state !== 'idle') return;
    if (pendingQuestions) {
      showWritePauseDot('ready');
    } else {
      showWritePauseDot('loading');  // questions still in flight
    }
  }, 2000);
}

// ─── Selection Sensor ─────────────────────────────────────────────────────────
// Fires when user highlights text. Shows a selection dot near the selection
// if the selected text contains a PM keyword.
// Disabled on Google Docs — getSelection() returns empty on canvas editors.

let selectionDebounceTimer = null;

document.addEventListener('selectionchange', () => {
  clearTimeout(selectionDebounceTimer);
  selectionDebounceTimer = setTimeout(() => {
    // Spec §Arch-3: prevent duplicate queries or re-triggering UI while onboarding is open
    if (isOnboarding) return;
    // Don't interrupt active voice session
    if (state !== 'idle') return;
    // Postcard visible: allow new selection — user may want a different excerpt

    const sel = window.getSelection();
    const text = sel ? sel.toString().trim() : '';

    // Hide dot if selection is too short. No upper cap — long selections are
    // truncated when sent to the RAG pipeline, not blocked here.
    if (text.length < 2) {
      hideSelectionDot();
      return;
    }

    // PM relevance gate — Groq page classification is the authority:
    //   pageIsPMContext === true  → any highlight gets the dot (semantic)
    //   pageIsPMContext === false → no dot, even with keyword match (Groq says not PM)
    //   pageIsPMContext === null  → regex fallback (Groq hasn't responded yet, ~first 2s)
    let showDot = false;
    if (pageIsPMContext === true) {
      showDot = true;  // PM page — all highlights qualify
    } else if (pageIsPMContext === null) {
      showDot = textMatchesPMRoot(text);  // Groq pending — regex fallback
    }
    // pageIsPMContext === false → showDot stays false (non-PM page, trust Groq)
    if (!showDot) {
      hideSelectionDot();
      return;
    }

    // Position dot near selection
    if (sel.rangeCount === 0) return;
    const range = sel.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return; // empty rect (Google Docs canvas)

    // Check onboarding status — async read is ~1ms; text is already captured in closure above.
    chrome.storage.local.get(['hasOnboarded'], (data) => {
      if (isOnboarding) return; // guard again after async gap
      if (!data.hasOnboarded) {
        // First-time user: show onboarding panel instead of selection dot.
        // text is in closure — safe; selection may already be cleared.
        showOnboarding(text);
      } else {
        // Returning user: normal selection dot behaviour.
        ambientState = 'selection-dot';
        showSelectionDot(rect);
      }
    });
  }, 150); // 150ms debounce — prevents flicker during drag-select
});

// ─── Activation ───────────────────────────────────────────────────────────────

function activateLennyLive() {
  if (state !== 'idle') return;

  // Spec §Arch-2: voice fired while onboarding is open — cancel onboarding.
  // Set onboardingCancelled so the in-flight text RAG result is silently discarded when it arrives.
  if (isOnboarding) {
    onboardingCancelled = true;
    isOnboarding = false;
    onboardingSelection = '';
    pendingOnboardingResult = null;
    shadow.getElementById('ll-onboarding').classList.add('hidden');
    console.log('[LennyLive] Double-tap Ctrl during onboarding — onboarding cancelled, voice takes over');
  }

  hideAllAmbientUI();
  state = 'listening';
  playPing();
  showIndicator('listening');
  startListening();
}

function cancelLennyLive() {
  state = 'idle';
  clearTimeout(timerA);
  clearTimeout(timerB);
  clearTimeout(processingTimeout); // fix: was missing — could leave ghost timeout
  if (typeof recognition !== 'undefined' && recognition) {
    try { recognition.abort(); } catch (_) {}
  }
  hideIndicator();
  console.log('[LennyLive] Cancelled — returned to idle');
}

// ─── Query Processing ─────────────────────────────────────────────────────────

let processingTimeout = null;

function processQuery(transcript) {
  // currentSelection was captured at activation time — do not re-read here
  // pageContext is captured now: the active block / main content at the moment of query
  const pageContext = extractPageContext();
  state = 'loading';
  showIndicator('loading');
  console.log('[LennyLive] Sending query:', { transcript, selection: currentSelection, pageContext: pageContext.slice(0, 60) });

  updateStreak(); // Streak fires on activation, not success

  // Fire-and-forget — no callback. RESPONSE arrives via chrome.runtime.onMessage listener below.
  chrome.runtime.sendMessage({
    type: 'QUERY',
    transcript,                   // field name matches service-worker expectation — do not rename
    selection: currentSelection,  // field name matches service-worker expectation — do not rename
    pageContext,                  // new: semantic page content for richer RAG context
  });

  // Safety timeout: if RESPONSE never arrives (e.g. service worker crashed),
  // return to idle after 10s so the user is never stuck.
  processingTimeout = setTimeout(() => {
    if (state === 'loading') {
      state = 'idle';
      hideIndicator();
      console.log('[LennyLive] Service worker timeout (10s) — returning to idle');
    }
  }, 10000);
}

function handleResponse(message) {
  // Cancel the safety timeout — real response arrived
  clearTimeout(processingTimeout);
  state = 'idle';
  hideIndicator();

  if (message.status === 'ok' && message.insight) {
    showPostcard(message.insight, message.relatedInsights || []);
  } else if (message.status === 'chitchat') {
    // Non-PM query — warm acknowledgement, zero ElevenLabs cost
    playBloop();
    showToast("That's outside my PM brain — try asking me about retention, pricing, growth, or any product challenge you're facing.");
    console.log('[LennyLive] Chitchat rejected — toast shown');
  } else if (message.status === 'no_results') {
    // Genuine no match — soft nudge to retry
    playBump();
    showToast("Didn't quite catch a question. Double-tap Ctrl to try again.");
    console.log('[LennyLive] No results — toast shown');
  } else if (message.status === 'network_error') {
    // Groq, ElevenLabs, or Supabase call failed — surface it immediately
    playBump();
    showToast('Network error. Lenny needs a second to reconnect.');
    console.warn('[LennyLive] Network error — toast shown');
  } else {
    console.warn('[LennyLive] Unhandled status:', message.status);
  }
}

// Single onMessage listener — handles RESPONSE (Push 1), AUDIO (Push 2), and QUESTIONS_READY
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'RESPONSE') {
    // Spec §Arch-2: buffer result while onboarding is visible — don't call showPostcard yet.
    if (isOnboarding) {
      if (message.status === 'ok' && message.insight) {
        pendingOnboardingResult = { insight: message.insight, relatedInsights: message.relatedInsights || [] };
        console.log('[LennyLive] Onboarding: RAG result buffered — will show on dismiss');
      } else {
        pendingOnboardingResult = null; // no results or error — dismiss cleanly
      }
      return;
    }
    // Spec §Arch-2: voice mode took over — silently discard this text RAG result.
    if (onboardingCancelled) {
      onboardingCancelled = false;
      console.log('[LennyLive] Discarding stale onboarding RAG result (voice took over)');
      return;
    }
    handleResponse(message);
  }
  if (message.type === 'AUDIO') {
    // Suppress audio during onboarding — buffer it for playback after dismiss.
    if (isOnboarding) {
      if (pendingOnboardingResult) {
        pendingOnboardingResult.audio = message.audio;
      }
      console.log('[LennyLive] Onboarding: audio buffered — will play on dismiss');
      return;
    }
    if (onboardingCancelled) return; // voice took over — discard
    playAudio(message.audio);
  }
  if (message.type === 'AUDIO_ERROR') {
    // Audio failed but postcard may be visible — don't show error toast (PRD v2 §4.1)
    console.warn('[LennyLive] Audio failed silently — postcard remains visible');
  }
  if (message.type === 'MUTE_CHANGED') {
    // Popup toggled mute — stop any currently-playing audio immediately (PRD v2 §4.5)
    if (message.muted) stopCurrentAudio();
  }
  if (message.type === 'QUESTIONS_READY') {
    // NOT_PM: model identified non-professional content — suppress badge silently
    if (message.notPm || (!message.error && (!message.questions || message.questions.length === 0))) {
      pendingQuestions = null;
      clearTimeout(dotAppearTimer);
      hideWritePauseDot();
      console.log('[LennyLive] QUESTIONS_READY: NOT_PM — badge suppressed');
      return;
    }

    // Groq error: fail-open — local gates already validated PM intent, don't go dark.
    // Serve template chips so the badge still appears and the chip fires the RAG pipeline.
    if (message.error) {
      const kw = message.keyword || 'this topic';
      pendingQuestions = {
        keyword: kw,
        questions: [
          `What's the most common mistake PMs make around ${kw}?`,
          `How do the best product teams think about ${kw}?`,
          `What should I know about ${kw} at my stage?`,
        ],
        blockContent: lastEagerFetchBlockContent,
        timestamp: Date.now(),
      };
      console.warn('[LennyLive] QUESTIONS_READY: Groq error — serving template chips (fail-open)');
      if (ambientState === 'write-pause-dot') updateWritePauseDotReady();
      return;
    }

    // Happy path: real chips from Groq
    pendingQuestions = {
      keyword: message.keyword,
      questions: message.questions,
      blockContent: lastEagerFetchBlockContent,
      timestamp: Date.now(),
    };

    // Cache chips so re-focus on same/related content doesn't re-call Groq.
    // concept from Groq is already canonical (e.g. "Retention Strategy") — no normalization needed.
    const ck = message.keyword || 'unknown';
    sessionChipsCache.set(ck, { keyword: message.keyword, questions: message.questions });
    lastKnownConcept = ck; // persist cache key for cache gate anchoring across keystrokes

    console.log('[LennyLive] QUESTIONS_READY:', message.keyword, message.questions);

    if (ambientState === 'write-pause-dot') {
      updateWritePauseDotReady();
    }
  }
  // Popup CTA: "Got it, let me try" sends this to make the nudge dot pulse prominently
  if (message.type === 'NUDGE_PULSE') {
    pulseNudge();
  }
  if (message.type === 'PAGE_CLASSIFIED') {
    pageIsPMContext = message.isPM;
    console.log('[LennyLive] Page classified: PM=' + message.isPM);
  }
  // Return nothing (no return true) — we never send a response back to the SW
});

// ─── Speech Recognition ───────────────────────────────────────────────────────

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

let recognition = null;
let timerA, timerB;

if (!SpeechRecognition) {
  console.warn('[LennyLive] SpeechRecognition not supported in this browser — activation disabled');
  // activateLennyLive will still run but startListening will no-op gracefully
}

if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = 'en-US';
  recognition.maxAlternatives = 1;

  recognition.onstart = () => {
    console.log('[LennyLive] Recognition started — Timer A (5s no-speech) running');
    timerA = setTimeout(() => {
      console.log('[LennyLive] Timer A fired — no speech detected, cancelling');
      cancelLennyLive();
    }, 5000);
  };

  recognition.onspeechstart = () => {
    console.log('[LennyLive] Speech detected — clearing Timer A');
    clearTimeout(timerA);
  };

  recognition.onspeechend = () => {
    console.log('[LennyLive] Speech ended — Timer B (2s post-silence) running');
    timerB = setTimeout(() => {
      console.log('[LennyLive] Timer B fired — processing query');
      // recognition.stop() triggers onresult if speech was captured
      try { recognition.stop(); } catch (_) {}
    }, 2000);
  };

  recognition.onresult = (e) => {
    clearTimeout(timerA);
    clearTimeout(timerB);
    const transcript = e.results[0][0].transcript;
    console.log('[LennyLive] Transcript:', transcript);
    processQuery(transcript);
  };

  recognition.onerror = (e) => {
    clearTimeout(timerA);
    clearTimeout(timerB);
    console.log('[LennyLive] Speech error:', e.error);
    if (e.error === 'not-allowed') {
      showMicDeniedTooltip();
    }
    cancelLennyLive();
  };

  recognition.onend = () => {
    // Fires when session ends for any reason (including natural browser termination).
    // If still in 'listening', no result was captured — return to idle.
    if (state === 'listening') {
      console.log('[LennyLive] Recognition ended without result — returning to idle');
      cancelLennyLive();
    }
  };
}

function startListening() {
  if (!recognition) {
    console.warn('[LennyLive] SpeechRecognition unavailable — cannot start listening');
    cancelLennyLive();
    return;
  }
  try {
    recognition.start();
    console.log('[LennyLive] Recognition started');
  } catch (err) {
    console.log('[LennyLive] Failed to start recognition:', err.message);
    cancelLennyLive();
  }
}

function stopListening() {
  clearTimeout(timerA);
  clearTimeout(timerB);
  if (recognition) {
    try { recognition.stop(); } catch (_) {}
  }
}

// ─── PM Buzzwords ─────────────────────────────────────────────────────────────
// Inlined — MV3 content scripts cannot import external modules.

// PM_ROOTS — stem-based regex for instant local detection (selection dot, reading sensor, clipboard).
// Uses word stems so morphological variants match: retent = retention/retentive,
// activat = activation/activated/activating, strateg = strategy/strategic/strategize.
// Multi-word phrases use [\s\-]+ as separators (NOT . which matches any char).
// NOTE: write+pause does NOT use this — Groq owns that detection path (Task 3).
// Short acronyms (≤4 chars) use \b word boundaries to prevent matching inside words
// (e.g. "starred" was matching ARR, "epicure" was matching epic).
// Longer stems (≥5 chars) don't need boundaries — substring matches are intentional
// (e.g. "retent" matches "retention", "retentive", "retenting").
const PM_ROOTS = /retent|retain(?!er)|churn|activat|growth[\s-]+loop|viral[\s-]+growth|acquisi|referral|network[\s-]+effect|funnel|cohort|north[\s-]+star|\bKPI\b|\bOKR\b|\bNPS\b|\bCSAT\b|\bDAU\b|\bMAU\b|\bWAU\b|\bLTV\b|\bCAC\b|\bARR\b|\bMRR\b|product[\s-]+market|\bPMF\b|strateg|position(?:ing)?|competit|differenti|moat|roadmap|prioriti|pricing|monetiz|freemium|paywall|upsell|subscript|free[\s-]+trial|revenue[\s-]+model|onboard|aha[\s-]+moment|time[\s-]+to[\s-]+value|user[\s-]+journey|drop[\s-]+off|go[\s-]+to[\s-]+market|\bGTM\b|product[\s-]+led|\bPLG\b|sprint|backlog|user[\s-]+stor|feature[\s-]+flag|dogfood|rollout|post[\s-]+mortem|user[\s-]+research|jobs[\s-]+to[\s-]+be|\bJTBD\b|A[\/\s]B[\s-]+test|experiment|persona(?!l\b)|stakehold|cross[\s-]+func|buy[\s-]+in|one[\s-]+pager|customer[\s-]+develop|feedback[\s-]+loop|feature[\s-]+request|power[\s-]+user|win[\s-]+loss|marketplac|cold[\s-]+start|\bMVP\b|zero[\s-]+to[\s-]+one|0[\s-]+to[\s-]+1|early[\s-]+stage|pre[\s-]+PMF|founding/i;

// Quick boolean PM root check — used by selection dot, reading sensor, and clipboard intercept.
// Write+pause does NOT use this — it sends to Groq directly after the 40-word threshold.
function textMatchesPMRoot(text) {
  return PM_ROOTS.test(text.slice(0, 5000));
}

// Returns a human-readable PM concept label for the onboarding concept pill,
// extracted from the PM_ROOTS match in the highlighted text.
// Returns null if no clean label is available (body text falls back to generic copy).
function getOnboardingConceptLabel(text) {
  const match = PM_ROOTS.exec(text);
  if (!match) return null;
  const stem = match[0].toLowerCase().replace(/[\s\-]+/g, '-');
  const LABEL_MAP = {
    'retent': 'Retention', 'retain': 'Retention', 'churn': 'Churn',
    'activat': 'Activation', 'growth-loop': 'Growth Loops', 'viral-growth': 'Viral Growth',
    'acquisi': 'Acquisition', 'referral': 'Referral', 'network-effect': 'Network Effects',
    'funnel': 'Conversion Funnel', 'cohort': 'Cohort Analysis', 'north-star': 'North Star Metric',
    'kpi': 'KPIs', 'okr': 'OKRs', 'nps': 'NPS', 'csat': 'CSAT',
    'dau': 'DAU / MAU', 'mau': 'DAU / MAU', 'wau': 'WAU', 'ltv': 'LTV / CAC', 'cac': 'LTV / CAC',
    'arr': 'ARR', 'mrr': 'MRR', 'product-market': 'Product-Market Fit', 'pmf': 'PMF',
    'strateg': 'Strategy', 'position': 'Positioning', 'competit': 'Competitive Moat',
    'differenti': 'Differentiation', 'moat': 'Moat', 'roadmap': 'Roadmap',
    'prioriti': 'Prioritization', 'pricing': 'Pricing', 'monetiz': 'Monetization',
    'freemium': 'Freemium', 'upsell': 'Upsell', 'subscript': 'Subscription',
    'onboard': 'Onboarding', 'aha-moment': 'Aha Moment', 'time-to-value': 'Time to Value',
    'user-journey': 'User Journey', 'drop-off': 'Drop-off', 'go-to-market': 'GTM Strategy',
    'gtm': 'GTM Strategy', 'product-led': 'Product-Led Growth', 'plg': 'PLG',
    'sprint': 'Agile / Sprint', 'backlog': 'Backlog', 'user-research': 'User Research',
    'jobs-to-be': 'Jobs to Be Done', 'jtbd': 'JTBD', 'a/b-test': 'A/B Testing',
    'experiment': 'Experimentation', 'persona': 'User Personas', 'stakehold': 'Stakeholders',
    'cross-func': 'Cross-functional', 'mvp': 'MVP', 'zero-to-one': 'Zero to One',
    '0-to-1': 'Zero to One', 'early-stage': 'Early Stage', 'pre-pmf': 'Pre-PMF',
    'founding': 'Founding PM',
  };
  return LABEL_MAP[stem] || null;
}

// Shows the onboarding panel and fires RAG in the background.
// selectedText: the highlighted string, already captured before selection can be cleared.
function showOnboarding(selectedText) {
  isOnboarding = true;
  onboardingCancelled = false;
  pendingOnboardingResult = null;
  onboardingSlide = 1;

  // Forcefully clear ALL ambient UI — widget and dots must never coexist on screen
  hideNudge(true);
  hideSelectionDot();
  hideAllAmbientUI();

  // Spec §Arch-1: store selected text NOW — window.getSelection() is cleared on next click.
  onboardingSelection = selectedText;

  // Static loading copy — no dynamic topic injection
  shadow.getElementById('ll-ob-body-text').textContent =
    'Analyzing your highlight. Lenny is cross-referencing this against frameworks and stories from 300+ top product leaders.';

  // Reset slides to slide 1 state
  shadow.getElementById('ll-ob-slide-1').classList.remove('hidden');
  shadow.getElementById('ll-ob-slide-2').classList.add('hidden');
  shadow.getElementById('ll-ob-dot-1').classList.add('active');
  shadow.getElementById('ll-ob-dot-2').classList.remove('active');
  shadow.getElementById('ll-ob-skip').classList.add('hidden');
  shadow.getElementById('ll-ob-next').textContent = 'Next →';

  // Show the panel
  shadow.getElementById('ll-onboarding').classList.remove('hidden');

  // Spec §Arch-1: fire RAG immediately using stored onboardingSelection, not live selection.
  chrome.runtime.sendMessage({
    type: 'QUERY',
    transcript: '',
    selection: onboardingSelection,
    pageContext: '',
  });

  console.log('[LennyLive] Onboarding shown — RAG firing for:', onboardingSelection.slice(0, 60));
}

// Dismisses the onboarding panel (called by Skip, Get Started, or ✕).
// If RAG result is already buffered, shows postcard immediately.
// If RAG is still in flight, shows loading indicator — postcard follows when RESPONSE arrives.
function dismissOnboarding() {
  chrome.storage.local.set({ hasOnboarded: true });
  isOnboarding = false;
  onboardingSelection = '';

  // Hide panel
  shadow.getElementById('ll-onboarding').classList.add('hidden');

  if (pendingOnboardingResult) {
    // RAG already returned — show postcard immediately
    showPostcard(pendingOnboardingResult.insight, pendingOnboardingResult.relatedInsights || []);
    // Play buffered audio now that postcard is visible
    if (pendingOnboardingResult.audio) playAudio(pendingOnboardingResult.audio);
    pendingOnboardingResult = null;
  } else {
    // RAG still in flight — show "Lenny is thinking…" indicator.
    // When RESPONSE arrives, the normal handleResponse() path runs and shows the postcard.
    showIndicator('loading');
  }

  console.log('[LennyLive] Onboarding dismissed');
}

// ─── Google Docs Clipboard Intercept ─────────────────────────────────────────
// Google Docs uses a canvas renderer — getSelection() and contenteditable detection
// both fail. Fallback: intercept copy events. When a PM copies text containing a
// PM keyword on docs.google.com, treat it as a selection trigger.
//
// UX framing: "On Google Docs, highlight + copy to ask Lenny."
// This is explicitly framed as a different interaction model, not a broken version
// of the standard flow. The behavior is honest: copy is the trigger.

if (location.hostname === 'docs.google.com') {
  document.addEventListener('copy', (e) => {
    // e.clipboardData.getData only available on cut/copy events, not paste
    const clipText = e.clipboardData?.getData('text/plain')?.trim() ?? '';

    if (clipText.length < 10 || clipText.length > 2000) return;

    if (!textMatchesPMRoot(clipText)) return;

    console.log('[LennyLive] Google Docs clipboard intercept — PM root match, length:', clipText.length);

    // Treat copied text as a selection — fire QUERY directly (same as selection dot click)
    // Small delay so the copy completes before we show UI
    setTimeout(() => {
      if (state !== 'idle') return;
      chrome.runtime.sendMessage({
        type: 'QUERY',
        transcript: '',
        selection: clipText.slice(0, 500),
        pageContext: '',
      });
    }, 100);
  });

  console.log('[LennyLive] Google Docs clipboard intercept active');
}

console.log('[LennyLive] Content script loaded — Shadow DOM ready');
